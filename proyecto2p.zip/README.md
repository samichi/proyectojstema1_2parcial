# proyectojstema1_2parcial
Proyecto del primer parcial usando el framework MEAN stack
